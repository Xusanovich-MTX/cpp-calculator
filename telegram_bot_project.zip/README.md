# Telegram Bot - Algebra Yordamchi

Bu bot `telebot` (pyTelegramBotAPI) kutubxonasiga asoslangan oddiy Telegram bot bo‘lib, foydalanuvchiga algebra darslari, savol javob va bot haqida ma’lumot beradi.

## Boshlash

1. PythonAnywhere.com saytida ro‘yxatdan o‘ting (Beginner account)
2. Fayllarni yuklang (`tgbot.py`, `requirements.txt`)
3. Bash console oching va quyidagilarni bajaring:

```bash
pip3 install --user -r requirements.txt
python3 tgbot.py
```

4. Bot ishlaydi — unga `/start` deb yozing!

## Token
`tgbot.py` ichidagi `TOKEN = 'YOUR_BOT_TOKEN_HERE'` qatoriga o‘z tokeningizni yozing.